@extends('layouts.app')

@section('title', 'Contact Page')

@section('content')
    <x-hero-section pageId="contact" />
@endsection
