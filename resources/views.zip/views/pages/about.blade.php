{{-- resources/views/pages/home.blade.php --}}
@extends('layouts.app')

@section('content')
    <h1>Welcome to the Homepage</h1>
@endsection
{{-- resources/views/pages/home.blade.php --}}
@extends('layouts.app')

@section('content')
    <h1>Welcome to the About page</h1>
@endsection
