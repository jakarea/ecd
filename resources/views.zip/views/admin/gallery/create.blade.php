@extends('admin.layouts.app')

@section('title', 'Create Gallery Item')

@section('content')
    <div class="container mx-auto px-4 py-6">
        {{-- Header --}}
        <div class="mb-6">
            <div class="flex items-center gap-2 text-sm text-gray-600 mb-2">
                <a href="{{ route('admin.gallery.index', ['locale' => request()->route('locale') ?? request()->segment(1)]) }}" class="hover:text-blue-600">Gallery</a>
                <span>/</span>
                <span>Create New Item</span>
            </div>
            <h1 class="text-3xl font-bold text-gray-900">Create Gallery Item</h1>
        </div>

        {{-- Form --}}
        <div class="bg-white rounded-lg shadow p-6">
            <form action="{{ route('admin.gallery.store', ['locale' => request()->route('locale') ?? request()->segment(1)]) }}" method="POST" enctype="multipart/form-data">
                @csrf
                @include('admin.gallery.form')

                <div class="flex justify-end gap-3 mt-6">
                    <a href="{{ route('admin.gallery.index', ['locale' => request()->route('locale') ?? request()->segment(1)]) }}"
                        class="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition">
                        Cancel
                    </a>
                    <button type="submit"
                        class="px-4 py-2 bg-[var(--color-brand)] text-white rounded-lg hover:opacity-90 transition">
                        Create Gallery Item
                    </button>
                </div>
            </form>
        </div>
    </div>
@endsection
